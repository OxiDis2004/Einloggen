﻿using System.Web;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Passworteingabe
{
    public partial class LoginForm : Form
    {
        private string connectingString = "Server=localhost;Database=users;User=App;Password=HpfN6H2SvIz**ViX";

        //Erstellt variable
        public int loginAttempt = 3; //Versuchen

        public LoginForm()
        {
            InitializeComponent();
            CenterToScreen();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            // Nimmt text von Inputbox
            string username = tbx_username.Text;
            string password = tbx_password.Text;

            if (username != null || password != null)
            {
                bool isAuthenticated = AuthenticateUser(username, password);

                if (isAuthenticated)
                {
                    MainForm userInfoForm = GetUserInfo(username);
                    userInfoForm.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show(
                        "Error",
                        "You enterned false date.",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error,
                        MessageBoxDefaultButton.Button1,
                        MessageBoxOptions.DefaultDesktopOnly);

                    tbx_username.Clear();
                    tbx_password.Clear();
                    loginAttempt--;

                    if (loginAttempt == 0)
                    {
                        DialogResult result = MessageBox.Show(
                            "У вас закончились попытки ввода.",
                            "Ошибка",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error,
                            MessageBoxDefaultButton.Button1,
                            MessageBoxOptions.DefaultDesktopOnly);

                        if (result == DialogResult.OK)
                        {
                            ResetPassword resetPasswordform = new ResetPassword();
                            resetPasswordform.Show();
                            this.Hide();
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show(
                    "Вы не ввели данные. Введите данные",
                    "Ошибка",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error,
                    MessageBoxDefaultButton.Button1,
                    MessageBoxOptions.DefaultDesktopOnly);

                tbx_username.Clear();
                tbx_password.Clear();
            }
        }

        public bool AuthenticateUser(string username, string password)
        {
            using (MySqlConnection connection = new MySqlConnection(connectingString))
            {
                connection.Open();

                string query = "SELECT COUNT(*) FROM users WHERE Username=@Username AND Password=@Password";


                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@Password", password);

                    object result = command.ExecuteScalar();

                    if (result != null)
                    {
                        int count = Convert.ToInt32(result);
                        return count > 0;
                    }
                    else
                    {
                        return false;
                    }

                }
            }
        }

        private MainForm GetUserInfo(string username)
        {
            MainForm userInfoForm = null;

            using (MySqlConnection connection = new MySqlConnection(connectingString))
            {
                connection.Open();

                string query = "SELECT Name, Surname, Birthday FROM users WHERE Username=@Username";

                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Username", username);

                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            string name = reader["Name"].ToString();
                            string surname = reader["Surname"].ToString();
                            DateTime birthday = (DateTime)reader["Birthday"];
                            userInfoForm = new MainForm(name, surname, birthday);
                        }
                    }
                }

                connection.Close();
            }

            return userInfoForm;
        }

        private void linkSingUp_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            RegistrForm form2 = new RegistrForm();
            form2.Show();
            this.Hide();
        }
    }
}