﻿namespace Passworteingabe
{
    partial class ResetPassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label1 = new Label();
            label4 = new Label();
            lbl_username = new Label();
            lbl_surname = new Label();
            lbl_name = new Label();
            tbx_new_passwort = new TextBox();
            tbx_username = new TextBox();
            tbx_surname = new TextBox();
            tbx_name = new TextBox();
            btn_reset = new Button();
            time_to_open = new System.Windows.Forms.Timer(components);
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 16.2F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(135, 32);
            label1.Name = "label1";
            label1.Size = new Size(212, 38);
            label1.TabIndex = 3;
            label1.Text = "Reset Password";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(46, 318);
            label4.Name = "label4";
            label4.Size = new Size(133, 28);
            label4.TabIndex = 19;
            label4.Text = "Neu Passwort:";
            // 
            // lbl_username
            // 
            lbl_username.AutoSize = true;
            lbl_username.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            lbl_username.Location = new Point(46, 252);
            lbl_username.Name = "lbl_username";
            lbl_username.Size = new Size(103, 28);
            lbl_username.TabIndex = 18;
            lbl_username.Text = "Username:";
            // 
            // lbl_surname
            // 
            lbl_surname.AutoSize = true;
            lbl_surname.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            lbl_surname.Location = new Point(45, 189);
            lbl_surname.Name = "lbl_surname";
            lbl_surname.Size = new Size(109, 28);
            lbl_surname.TabIndex = 17;
            lbl_surname.Text = "Nachname:";
            // 
            // lbl_name
            // 
            lbl_name.AutoSize = true;
            lbl_name.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            lbl_name.Location = new Point(45, 123);
            lbl_name.Name = "lbl_name";
            lbl_name.Size = new Size(94, 28);
            lbl_name.TabIndex = 16;
            lbl_name.Text = "Vorname:";
            // 
            // tbx_new_passwort
            // 
            tbx_new_passwort.Location = new Point(193, 318);
            tbx_new_passwort.Name = "tbx_new_passwort";
            tbx_new_passwort.Size = new Size(255, 27);
            tbx_new_passwort.TabIndex = 15;
            tbx_new_passwort.UseSystemPasswordChar = true;
            // 
            // tbx_username
            // 
            tbx_username.Location = new Point(193, 252);
            tbx_username.Name = "tbx_username";
            tbx_username.Size = new Size(254, 27);
            tbx_username.TabIndex = 14;
            // 
            // tbx_surname
            // 
            tbx_surname.Location = new Point(193, 193);
            tbx_surname.Name = "tbx_surname";
            tbx_surname.Size = new Size(172, 27);
            tbx_surname.TabIndex = 13;
            // 
            // tbx_name
            // 
            tbx_name.Location = new Point(193, 127);
            tbx_name.Name = "tbx_name";
            tbx_name.Size = new Size(172, 27);
            tbx_name.TabIndex = 12;
            // 
            // btn_reset
            // 
            btn_reset.Cursor = Cursors.Hand;
            btn_reset.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            btn_reset.Location = new Point(160, 406);
            btn_reset.Name = "btn_reset";
            btn_reset.Size = new Size(135, 51);
            btn_reset.TabIndex = 20;
            btn_reset.Text = "Reset";
            btn_reset.UseVisualStyleBackColor = true;
            btn_reset.Click += btn_reset_Click;
            // 
            // time_to_open
            // 
            time_to_open.Interval = 60000;
            time_to_open.Tick += time_to_open_Tick;
            // 
            // ResetPassword
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(512, 500);
            Controls.Add(btn_reset);
            Controls.Add(label4);
            Controls.Add(lbl_username);
            Controls.Add(lbl_surname);
            Controls.Add(lbl_name);
            Controls.Add(tbx_new_passwort);
            Controls.Add(tbx_username);
            Controls.Add(tbx_surname);
            Controls.Add(tbx_name);
            Controls.Add(label1);
            Name = "ResetPassword";
            Text = "ResetPassword";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label1;
        private Label label4;
        private Label lbl_username;
        private Label lbl_surname;
        private Label lbl_name;
        private TextBox tbx_new_passwort;
        private TextBox tbx_username;
        private TextBox tbx_surname;
        private TextBox tbx_name;
        private Button btn_reset;
        private System.Windows.Forms.Timer time_to_open;
    }
}