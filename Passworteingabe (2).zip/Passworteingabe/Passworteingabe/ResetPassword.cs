﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Passworteingabe
{
    public partial class ResetPassword : Form
    {
        private string connectingString = "Server=localhost;Database=users;User=App;Password=HpfN6H2SvIz**ViX";
        public int resetAttempt = 3;

        public ResetPassword()
        {
            InitializeComponent();
            CenterToScreen();
            time_to_open.Enabled = false;
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            // Получение данных из текстовых полей
            string name = tbx_name.Text;
            string surname = tbx_surname.Text;
            string username = tbx_username.Text;
            string new_password = tbx_new_passwort.Text;

            DialogResult result = Reset_Password(name, surname, username, new_password);

            if (result == DialogResult.Yes)
            {
                LoginForm login = new LoginForm();
                login.Show();
                this.Hide();
            }
            else
            {
                resetAttempt--;
                MessageBox.Show(
                    "Error",
                    "You enterned false date ",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error,
                    MessageBoxDefaultButton.Button1,
                    MessageBoxOptions.DefaultDesktopOnly);

                tbx_name.Clear();
                tbx_surname.Clear();
                tbx_username.Clear();
                tbx_new_passwort.Clear();

                if (resetAttempt == 0)
                {
                    result = MessageBox.Show(
                        "Error",
                        "You enterned false date. You have lost all attempts. Maybe you hadn't sing up. Do that now!",
                        MessageBoxButtons.YesNoCancel,
                        MessageBoxIcon.Error,
                        MessageBoxDefaultButton.Button1,
                        MessageBoxOptions.DefaultDesktopOnly);

                    if (result == DialogResult.Yes)
                    {
                        RegistrForm registr = new RegistrForm();
                        registr.Show();
                        this.Hide();
                    }
                    else if (result == DialogResult.No)
                    {
                        time_to_open.Enabled = true;
                        btn_reset.Enabled = false;
                        tbx_name.Enabled = false;
                        tbx_surname.Enabled = false;
                        tbx_username.Enabled = false;
                        tbx_new_passwort.Enabled = false;
                    }
                    else
                    {
                        this.Hide();
                        LoginForm login = new LoginForm();
                        login.Show();
                    }
                }
            }


        }

        private DialogResult Reset_Password(string name, string surname, string username, string new_password)
        {
            DialogResult result;
            // Поключение к базе
            using (MySqlConnection connection = new MySqlConnection(connectingString))
            {
                connection.Open();

                // SQL-запрос для проверки данных в таблице
                string chandeQuery = "UPDATE users SET Password=@New_password WHERE Name=@Name AND Surname=@Surname AND Username=@Username";

                using (MySqlCommand command = new MySqlCommand(chandeQuery, connection))
                {
                    // Добавление параметров к запросу
                    command.Parameters.AddWithValue("@Name", name);
                    command.Parameters.AddWithValue("@Surname", surname);
                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@New_password", new_password);

                    // Выполнение запроса
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // Пароль успешно обновлен
                        result = MessageBox.Show(
                            "Пароль успешно обновлен.",
                            "Information",
                            MessageBoxButtons.YesNo,
                            MessageBoxIcon.Information,
                            MessageBoxDefaultButton.Button1,
                            MessageBoxOptions.DefaultDesktopOnly);

                    }
                    else
                    {
                        // Ничего не было обновлено, возможно, не найдены соответствующие записи
                        result = MessageBox.Show(
                            "Не найдено соответствующих записей. Пароль не был обновлен.",
                            "Error",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error,
                            MessageBoxDefaultButton.Button1,
                            MessageBoxOptions.DefaultDesktopOnly);
                    }

                    return result;
                }
            }
        }

        private void time_to_open_Tick(object sender, EventArgs e)
        {
            time_to_open.Enabled = false;
            btn_reset.Enabled = true;
            tbx_name.Enabled = true;
            tbx_surname.Enabled = true;
            tbx_username.Enabled = true;
            tbx_new_passwort.Enabled = true;
        }
    }
}
