﻿namespace Passworteingabe
{
    partial class RegistrForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lbl_singup = new Label();
            tbx_name = new TextBox();
            tbx_surname = new TextBox();
            tbx_username = new TextBox();
            tbx_passwort = new TextBox();
            dateTimePicker1 = new DateTimePicker();
            btn_save = new Button();
            tbx_password_check = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            tbx_adresse = new TextBox();
            label7 = new Label();
            label8 = new Label();
            rbtn_male = new RadioButton();
            label9 = new Label();
            tbx_mail = new TextBox();
            rbtn_female = new RadioButton();
            SuspendLayout();
            // 
            // lbl_singup
            // 
            lbl_singup.AutoSize = true;
            lbl_singup.Font = new Font("Segoe UI Semibold", 16.2F, FontStyle.Bold, GraphicsUnit.Point);
            lbl_singup.Location = new Point(401, 24);
            lbl_singup.Name = "lbl_singup";
            lbl_singup.Size = new Size(185, 38);
            lbl_singup.TabIndex = 0;
            lbl_singup.Text = "Registrierung";
            // 
            // tbx_name
            // 
            tbx_name.Location = new Point(167, 117);
            tbx_name.Name = "tbx_name";
            tbx_name.Size = new Size(244, 27);
            tbx_name.TabIndex = 1;
            tbx_name.KeyPress += Letter_KeyPress;
            // 
            // tbx_surname
            // 
            tbx_surname.Location = new Point(167, 183);
            tbx_surname.Name = "tbx_surname";
            tbx_surname.Size = new Size(244, 27);
            tbx_surname.TabIndex = 2;
            tbx_surname.KeyPress += Letter_KeyPress;
            // 
            // tbx_username
            // 
            tbx_username.Location = new Point(676, 114);
            tbx_username.Name = "tbx_username";
            tbx_username.Size = new Size(254, 27);
            tbx_username.TabIndex = 3;
            // 
            // tbx_passwort
            // 
            tbx_passwort.Location = new Point(676, 180);
            tbx_passwort.Name = "tbx_passwort";
            tbx_passwort.Size = new Size(255, 27);
            tbx_passwort.TabIndex = 4;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(167, 249);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(244, 27);
            dateTimePicker1.TabIndex = 5;
            // 
            // btn_save
            // 
            btn_save.Cursor = Cursors.Hand;
            btn_save.FlatAppearance.BorderColor = Color.Red;
            btn_save.FlatAppearance.BorderSize = 5;
            btn_save.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            btn_save.Location = new Point(416, 431);
            btn_save.Name = "btn_save";
            btn_save.Size = new Size(135, 36);
            btn_save.TabIndex = 6;
            btn_save.Text = "Registrieren";
            btn_save.UseVisualStyleBackColor = true;
            btn_save.Click += btn_save_Click;
            // 
            // tbx_password_check
            // 
            tbx_password_check.Location = new Point(676, 249);
            tbx_password_check.Name = "tbx_password_check";
            tbx_password_check.Size = new Size(255, 27);
            tbx_password_check.TabIndex = 7;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(19, 113);
            label1.Name = "label1";
            label1.Size = new Size(94, 28);
            label1.TabIndex = 8;
            label1.Text = "Vorname:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(19, 179);
            label2.Name = "label2";
            label2.Size = new Size(109, 28);
            label2.TabIndex = 9;
            label2.Text = "Nachname:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(471, 113);
            label3.Name = "label3";
            label3.Size = new Size(103, 28);
            label3.TabIndex = 10;
            label3.Text = "Username:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(471, 179);
            label4.Name = "label4";
            label4.Size = new Size(92, 28);
            label4.TabIndex = 11;
            label4.Text = "Passwort:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(471, 247);
            label5.Name = "label5";
            label5.Size = new Size(199, 28);
            label5.TabIndex = 12;
            label5.Text = "Widerholen Passwort:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(19, 245);
            label6.Name = "label6";
            label6.Size = new Size(142, 28);
            label6.TabIndex = 13;
            label6.Text = "Geburtsdatum:";
            // 
            // tbx_adresse
            // 
            tbx_adresse.Location = new Point(168, 303);
            tbx_adresse.Name = "tbx_adresse";
            tbx_adresse.Size = new Size(243, 27);
            tbx_adresse.TabIndex = 14;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label7.Location = new Point(19, 303);
            label7.Name = "label7";
            label7.Size = new Size(84, 28);
            label7.TabIndex = 16;
            label7.Text = "Adresse:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label8.Location = new Point(19, 355);
            label8.Name = "label8";
            label8.Size = new Size(46, 28);
            label8.TabIndex = 17;
            label8.Text = "Sex:";
            // 
            // rbtn_male
            // 
            rbtn_male.AutoSize = true;
            rbtn_male.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            rbtn_male.Location = new Point(168, 360);
            rbtn_male.Name = "rbtn_male";
            rbtn_male.Size = new Size(71, 29);
            rbtn_male.TabIndex = 18;
            rbtn_male.Text = "male";
            rbtn_male.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label9.Location = new Point(471, 305);
            label9.Name = "label9";
            label9.Size = new Size(72, 28);
            label9.TabIndex = 21;
            label9.Text = "E-Mail:";
            // 
            // tbx_mail
            // 
            tbx_mail.Location = new Point(676, 307);
            tbx_mail.Name = "tbx_mail";
            tbx_mail.Size = new Size(255, 27);
            tbx_mail.TabIndex = 20;
            // 
            // rbtn_female
            // 
            rbtn_female.AutoSize = true;
            rbtn_female.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            rbtn_female.Location = new Point(325, 360);
            rbtn_female.Name = "rbtn_female";
            rbtn_female.Size = new Size(86, 29);
            rbtn_female.TabIndex = 22;
            rbtn_female.Text = "female";
            rbtn_female.UseVisualStyleBackColor = true;
            // 
            // RegistrForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(978, 479);
            Controls.Add(rbtn_female);
            Controls.Add(label9);
            Controls.Add(tbx_mail);
            Controls.Add(rbtn_male);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(tbx_adresse);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(tbx_password_check);
            Controls.Add(btn_save);
            Controls.Add(dateTimePicker1);
            Controls.Add(tbx_passwort);
            Controls.Add(tbx_username);
            Controls.Add(tbx_surname);
            Controls.Add(tbx_name);
            Controls.Add(lbl_singup);
            Name = "RegistrForm";
            Text = "Registrierung";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbl_singup;
        private Button btn_save;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        public TextBox tbx_name;
        public TextBox tbx_surname;
        public TextBox tbx_username;
        public TextBox tbx_passwort;
        public DateTimePicker dateTimePicker1;
        public TextBox tbx_password_check;
        private TextBox tbx_adresse;
        private Label label7;
        private Label label8;
        private RadioButton rbtn_male;
        private Label label9;
        public TextBox tbx_mail;
        private RadioButton rbtn_female;
    }
}