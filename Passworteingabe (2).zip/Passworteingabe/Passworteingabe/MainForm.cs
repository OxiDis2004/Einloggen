﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Passworteingabe
{
    public partial class MainForm : Form
    {
        public MainForm(string name, string surname, DateTime birthday)
        {
            InitializeComponent();
            CenterToScreen();
            lbl_name.Text = name;
            lbl_surname.Text = surname;
            lbl_birthday.Text = birthday.ToShortDateString();
        }
    }
}
