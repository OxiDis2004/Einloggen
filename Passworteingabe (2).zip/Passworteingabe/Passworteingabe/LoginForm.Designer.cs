﻿namespace Passworteingabe
{
    partial class LoginForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            tbx_password = new TextBox();
            label1 = new Label();
            lbl_password = new Label();
            btn_login = new Button();
            time_to_enable = new System.Windows.Forms.Timer(components);
            lbl_singup = new Label();
            link_SingUp = new LinkLabel();
            lbl_login = new Label();
            tbx_username = new TextBox();
            SuspendLayout();
            // 
            // tbx_password
            // 
            tbx_password.Location = new Point(23, 238);
            tbx_password.Name = "tbx_password";
            tbx_password.Size = new Size(319, 27);
            tbx_password.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(210, 25);
            label1.Name = "label1";
            label1.Size = new Size(246, 38);
            label1.TabIndex = 1;
            label1.Text = " EInlogin in Profil";
            // 
            // lbl_password
            // 
            lbl_password.AutoSize = true;
            lbl_password.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            lbl_password.Location = new Point(16, 204);
            lbl_password.Name = "lbl_password";
            lbl_password.Size = new Size(113, 31);
            lbl_password.TabIndex = 2;
            lbl_password.Text = "Passwort:";
            // 
            // btn_login
            // 
            btn_login.BackColor = Color.LightGreen;
            btn_login.Cursor = Cursors.Hand;
            btn_login.Location = new Point(97, 307);
            btn_login.Name = "btn_login";
            btn_login.Size = new Size(135, 54);
            btn_login.TabIndex = 3;
            btn_login.Text = "Login";
            btn_login.UseVisualStyleBackColor = false;
            btn_login.Click += btn_login_Click;
            // 
            // time_to_enable
            // 
            time_to_enable.Interval = 1000;
            // 
            // lbl_singup
            // 
            lbl_singup.AutoSize = true;
            lbl_singup.Font = new Font("Segoe UI Semibold", 16.2F, FontStyle.Bold, GraphicsUnit.Point);
            lbl_singup.Location = new Point(396, 175);
            lbl_singup.Name = "lbl_singup";
            lbl_singup.Size = new Size(367, 38);
            lbl_singup.TabIndex = 5;
            lbl_singup.Text = "Haben Sie noch kein Profil, ";
            // 
            // link_SingUp
            // 
            link_SingUp.AutoSize = true;
            link_SingUp.Font = new Font("Segoe UI Semibold", 16.2F, FontStyle.Bold, GraphicsUnit.Point);
            link_SingUp.Location = new Point(430, 213);
            link_SingUp.Name = "link_SingUp";
            link_SingUp.Size = new Size(256, 38);
            link_SingUp.TabIndex = 6;
            link_SingUp.TabStop = true;
            link_SingUp.Text = "dann mach es jetzt";
            link_SingUp.LinkClicked += linkSingUp_LinkClicked;
            // 
            // lbl_login
            // 
            lbl_login.AutoSize = true;
            lbl_login.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            lbl_login.Location = new Point(16, 104);
            lbl_login.Name = "lbl_login";
            lbl_login.Size = new Size(124, 31);
            lbl_login.TabIndex = 8;
            lbl_login.Text = "Username:";
            // 
            // tbx_username
            // 
            tbx_username.Location = new Point(23, 138);
            tbx_username.Name = "tbx_username";
            tbx_username.Size = new Size(319, 27);
            tbx_username.TabIndex = 7;
            // 
            // LoginForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlDarkDark;
            ClientSize = new Size(769, 391);
            Controls.Add(lbl_login);
            Controls.Add(tbx_username);
            Controls.Add(link_SingUp);
            Controls.Add(lbl_singup);
            Controls.Add(btn_login);
            Controls.Add(lbl_password);
            Controls.Add(label1);
            Controls.Add(tbx_password);
            Name = "LoginForm";
            Text = "Geräte";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label1;
        private Label lbl_password;
        private Button btn_login;
        private System.Windows.Forms.Timer time_to_enable;
        private Label lbl_singup;
        private LinkLabel link_SingUp;
        private Label lbl_login;
        public TextBox tbx_password;
        public TextBox tbx_username;
    }
}