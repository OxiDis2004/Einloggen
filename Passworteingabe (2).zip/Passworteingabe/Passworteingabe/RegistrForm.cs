﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Passworteingabe
{
    public partial class RegistrForm : Form
    {
        private string connectingString = "Server=localhost;Database=users;User=App;Password=HpfN6H2SvIz**ViX";


        public RegistrForm()
        {
            InitializeComponent();
            CenterToScreen();
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            // Получение данных из текстовых полей
            string name = tbx_name.Text;
            string surname = tbx_surname.Text;
            string username = tbx_username.Text;
            string password = tbx_passwort.Text;
            string password_check = tbx_password_check.Text;
            DateTime birthday = dateTimePicker1.Value;
            string adress = tbx_adresse.Text;
            string email = tbx_mail.Text;




            // Проверка пароля
            if (password == password_check)
            {
                DialogResult result = Set_To_Database(name, surname, username, password, birthday);

                if (result == DialogResult.Yes)
                {
                    LoginForm main = new LoginForm();
                    main.Show();
                    this.Hide();
                }
                else if (result == DialogResult.No)
                {
                    Close();
                }
            }
            else
            {
                MessageBox.Show("Повторите ещё раз. Пароли не совподают.");
                tbx_passwort.Clear();
                tbx_password_check.Clear();
            }
        }

        private DialogResult Set_To_Database(string name, string surname, string username, string password, DateTime birthday)
        {
            DialogResult result;

            // Выполнение вставки данных в базу данных
            using (MySqlConnection connection = new MySqlConnection(connectingString))
            {
                connection.Open();

                // SQL-запрос для вставки данных в таблицу
                string insertQuery = "INSERT INTO users (Name, Surname, Username, Password, Birthday) VALUES (@Name, @Surname, @Username, @Password, @Birthday)";

                using (MySqlCommand command = new MySqlCommand(insertQuery, connection))
                {
                    // Добавление параметров к запросу
                    command.Parameters.AddWithValue("@Name", name);
                    command.Parameters.AddWithValue("@Surname", surname);
                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@Password", password);
                    command.Parameters.AddWithValue("@Birthday", birthday);

                    // Выполнение запроса
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        result = MessageBox.Show(
                            "Вы успешно зарегестрирывались. Войдите пожалуйста, чтобы продолжить.",
                            "Регестрация была успешна",
                            MessageBoxButtons.YesNo,
                            MessageBoxIcon.Information,
                            MessageBoxDefaultButton.Button1,
                            MessageBoxOptions.DefaultDesktopOnly);
                    }
                    else
                    {
                        MessageBox.Show("  добавлении данных в базу данных.");
                        result = MessageBox.Show(
                            "Ошибка при регестрацый. Пожалуйста, повторите свою попытку.",
                            "Регестрация не прошла",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error,
                            MessageBoxDefaultButton.Button1,
                            MessageBoxOptions.DefaultDesktopOnly);

                    }
                }

                connection.Close();
            }

            // Очистка текстовых полей
            tbx_name.Clear();
            tbx_surname.Clear();
            tbx_username.Clear();
            tbx_passwort.Clear();
            tbx_password_check.Clear();
            dateTimePicker1.Value = DateTime.Now;
            tbx_adresse.Clear();
            tbx_mail.Clear();
            rbtn_female.Checked = false;
            rbtn_male.Enabled = false;

            return result;
        }

        private void Letter_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        //static void NurBuchstaben(object sender, KeyPressEventArgs e)
        //{
        //    if(!char.IsLetter(e.KeyChar))
        //    {
        //        e.Handled = true;
        //    }
        //}
    }
}
