﻿namespace Passworteingabe
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lbl_name = new Label();
            lbl_surname = new Label();
            lbl_birthday = new Label();
            SuspendLayout();
            // 
            // lbl_name
            // 
            lbl_name.AutoSize = true;
            lbl_name.Location = new Point(75, 62);
            lbl_name.Name = "lbl_name";
            lbl_name.Size = new Size(50, 20);
            lbl_name.TabIndex = 0;
            lbl_name.Text = "label1";
            // 
            // lbl_surname
            // 
            lbl_surname.AutoSize = true;
            lbl_surname.Location = new Point(188, 62);
            lbl_surname.Name = "lbl_surname";
            lbl_surname.Size = new Size(50, 20);
            lbl_surname.TabIndex = 1;
            lbl_surname.Text = "label2";
            // 
            // lbl_birthday
            // 
            lbl_birthday.AutoSize = true;
            lbl_birthday.Location = new Point(280, 62);
            lbl_birthday.Name = "lbl_birthday";
            lbl_birthday.Size = new Size(50, 20);
            lbl_birthday.TabIndex = 2;
            lbl_birthday.Text = "label3";
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lbl_birthday);
            Controls.Add(lbl_surname);
            Controls.Add(lbl_name);
            Name = "MainForm";
            Text = "Account";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbl_name;
        private Label lbl_surname;
        private Label lbl_birthday;
    }
}